export class Location {
  constructor(public lat: number, public lng: number) {}
}
