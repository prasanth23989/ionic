#ifndef CREATE_STRING_H
#define CREATE_STRING_H

#include <nan.h>

char* create_string(Nan::MaybeLocal<v8::Value>);

#endif
